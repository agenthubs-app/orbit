# P22 · 报名结果

[返回页面目录](../PAGE_CATALOG.md) · [独立设计图](../screens/22-registration-result.jpg)

![报名结果设计参考](../screens/22-registration-result.jpg)

## 定位

路由／状态：`/events/[id]/register（结果状态）`。实现标记：现有结果语义＋设计状态。本页图是静态设计参考，不是运行中 App 的截图。

页面目标：已报名、待审核、失败、取消等结果需真实区分。

## 入口与返回

提交报名后的结果状态。

## 信息与动作

主要信息：明确区分已报名、待审核、失败、已取消。

操作及去向：回活动；仅在允许时修改资料或取消。

## 业务边界

示例是服务端已确认的已报名，不代表所有活动自动通过。

## 布局要求

这是二级／表单／独立工作页，不显示全局底部导航；使用标准返回入口，保留来源上下文。 采用浅蓝章节、左侧细蓝线、对齐字段与轻分隔线。字号、触控、行高和安全区以 [UI 规格](../UI_DESIGN_SPEC.md) 为准，不从 JPEG 像素直接换算。

## 状态与验收

在主状态之外补齐适用的加载、空内容、搜索无结果、请求失败、无权限／过期状态。表单还需键盘遮挡、验证失败、保存中、保存失败保留输入与未保存退出提示；不适用的状态应标明，不强行增加功能。

至少核对：返回到原来源；动作对象不串号；失败不显示成功；长文本和系统大字号不截断关键内容。详细场景见 [状态与验收](../STATES_AND_ACCEPTANCE.md)，业务流程见 [功能规格](../FUNCTIONAL_SPEC.md)。

## 图像校订

图片决定视觉方向，字段权限、数据状态、按钮可用性以文字规格与真实契约为准。头像、事件和数值均为虚构样例；生成图中的额外文案或装饰不自动成为需求。

## 画面细化参考

以下是本页首轮图像的具体画面说明，便于复现视觉意图；它不是 API 规范。如与上方业务说明冲突，以中文业务说明为准。原始生成与校订记录保留在未压缩完整版；本上传版保留逐页画面说明。

Secondary 报名结果, back 活动详情, NOdock. Success-state fixture with serverconfirmed registration (not pendingreview). Modest blue check icon and 已报名, subtitle 报名资料已保存。 Event thumbnail 周末产品交流会, 9月12日周六14:00 东京·涩谷. Pale-blue chapter 我的报名资料; aligned 姓名 程川 / 行业 互联网; multiline 参会目标 想交流早期产品的用户研究方法。 Primary 查看活动, quiet 修改报名资料 (if allowed fixture) and distinct redtext 取消报名. No fakeQRticket, attendeecountincrease, paymentreceipt, automatic calendareventsuccess or countdown. Use one coherent factual successstate.
